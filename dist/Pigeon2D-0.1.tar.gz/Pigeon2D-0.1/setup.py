from setuptools import setup
setup(name='Pigeon2D',
      version='0.1',
      description='A game engine for python pygame.',
      url='https://github.com/desvasicek/Pigeon2d',
      author='desvasicek',
      author_email=None,
      license='MIT',
      packages=[],
      zip_safe=False)
